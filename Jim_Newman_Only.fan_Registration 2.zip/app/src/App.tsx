import { Routes, Route } from 'react-router'
import { ThemeProvider } from '@/providers/theme'
import { Toaster } from '@/components/ui/sonner'
import Navbar from '@/components/Navbar'
import ChatWidget from '@/components/ChatWidget'
import Home from '@/pages/Home'
import Register from '@/pages/Register'
import Card from '@/pages/Card'
import Payment from '@/pages/Payment'
import Admin from '@/pages/Admin'

export default function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen transition-colors duration-300" style={{ backgroundColor: 'var(--color-bg)' }}>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/card" element={<Card />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
        <ChatWidget />
        <Toaster position="top-right" richColors />
      </div>
    </ThemeProvider>
  )
}
