import { useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useTheme } from "@/providers/theme";
import { Camera, CloudUpload, Check, Shield, RefreshCw } from "lucide-react";
import { toast } from "sonner";

export default function Register() {
  const { theme } = useTheme();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [form, setForm] = useState({
    fullName: "",
    instagramUsername: "",
    email: "",
    phone: "",
    dateOfBirth: "",
    address: "",
  });
  const [idDocument, setIdDocument] = useState<string | null>(null);
  const [faceCapture, setFaceCapture] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const registerMutation = trpc.fan.register.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      localStorage.setItem("fanId", data.fanId);
      navigate("/card");
    },
    onError: (error) => {
      toast.error(error.message);
      setSubmitting(false);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error("File too large. Max 10MB.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setIdDocument(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
      }
    } catch {
      toast.error("Could not access camera. Please allow camera permissions.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
      setCameraActive(false);
    }
  }, []);

  const captureFace = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(video, 0, 0);
      const dataUrl = canvas.toDataURL("image/png");
      setFaceCapture(dataUrl);
      stopCamera();
    }
  }, [stopCamera]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!form.fullName.trim()) newErrors.fullName = "Full name is required";
    if (!form.instagramUsername.trim()) newErrors.instagramUsername = "Instagram username is required";
    if (!form.email.trim()) newErrors.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) newErrors.email = "Invalid email";
    if (!form.phone.trim()) newErrors.phone = "Phone is required";
    if (!form.dateOfBirth) newErrors.dateOfBirth = "Date of birth is required";
    if (!form.address.trim()) newErrors.address = "Address is required";
    if (!idDocument) newErrors.idDocument = "ID document is required";
    if (!faceCapture) newErrors.faceCapture = "Face capture is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      toast.error("Please fill all required fields");
      return;
    }
    setSubmitting(true);
    registerMutation.mutate({
      ...form,
      idDocument: idDocument || undefined,
      faceCapture: faceCapture || undefined,
    });
  };

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-3xl mx-auto">
        <div
          className="rounded-3xl p-8 md:p-12"
          style={{
            backgroundColor: "var(--color-surface)",
            border: `1px solid ${theme === "dark" ? "rgba(184,134,11,0.3)" : "rgba(184,134,11,0.4)"}`,
            boxShadow: "0 4px 24px rgba(0,0,0,0.15)",
          }}
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
              Fan Registration
            </h1>
            <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
              Complete all fields to receive your Bronze Fan ID
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                  Full Name *
                </label>
                <input
                  type="text"
                  value={form.fullName}
                  onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                  style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid ${errors.fullName ? "#ef4444" : "var(--color-border)"}`}}
                  placeholder="John Doe"
                />
                {errors.fullName && <p className="text-xs mt-1 text-red-500">{errors.fullName}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                  Instagram Username *
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm" style={{ color: "var(--color-text-secondary)" }}>@</span>
                  <input
                    type="text"
                    value={form.instagramUsername}
                    onChange={(e) => setForm({ ...form, instagramUsername: e.target.value })}
                    className="w-full pl-8 pr-4 py-3 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                    style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid ${errors.instagramUsername ? "#ef4444" : "var(--color-border)"}`}}
                    placeholder="username"
                  />
                </div>
                {errors.instagramUsername && <p className="text-xs mt-1 text-red-500">{errors.instagramUsername}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                  Email Address *
                </label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                  style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid ${errors.email ? "#ef4444" : "var(--color-border)"}`}}
                  placeholder="you@example.com"
                />
                {errors.email && <p className="text-xs mt-1 text-red-500">{errors.email}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                  Phone Number *
                </label>
                <input
                  type="tel"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                  style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid ${errors.phone ? "#ef4444" : "var(--color-border)"}`}}
                  placeholder="+1 (555) 000-0000"
                />
                {errors.phone && <p className="text-xs mt-1 text-red-500">{errors.phone}</p>}
              </div>

              <div>
                <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                  Date of Birth *
                </label>
                <input
                  type="date"
                  value={form.dateOfBirth}
                  onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                  style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid ${errors.dateOfBirth ? "#ef4444" : "var(--color-border)"}`}}
                />
                {errors.dateOfBirth && <p className="text-xs mt-1 text-red-500">{errors.dateOfBirth}</p>}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                Mailing Address *
              </label>
              <textarea
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                rows={3}
                className="w-full px-4 py-3 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)] resize-none"
                style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid ${errors.address ? "#ef4444" : "var(--color-border)"}`}}
                placeholder="123 Broadway Ave, New York, NY 10001"
              />
              {errors.address && <p className="text-xs mt-1 text-red-500">{errors.address}</p>}
            </div>

            {/* ID Upload Section */}
            <div className="pt-4">
              <div className="flex items-center gap-2 mb-4">
                <Shield size={20} className="text-[var(--color-bronze)]" />
                <h3 className="text-lg font-semibold" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
                  Identity Verification
                </h3>
              </div>
              <div
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const file = e.dataTransfer.files[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => setIdDocument(event.target?.result as string);
                    reader.readAsDataURL(file);
                  }
                }}
                className="border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all duration-300 hover:border-[var(--color-bronze)] hover:bg-[rgba(184,134,11,0.05)]"
                style={{ borderColor: errors.idDocument ? "#ef4444" : "#cd7f32" }}
              >
                <input ref={fileInputRef} type="file" accept=".jpg,.jpeg,.png,.pdf" className="hidden" onChange={handleFileChange} />
                {idDocument ? (
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center">
                      <Check size={28} className="text-green-500" />
                    </div>
                    <p className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>Document uploaded successfully</p>
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); setIdDocument(null); }}
                      className="text-xs underline"
                      style={{ color: "var(--color-text-secondary)" }}
                    >
                      Remove and upload another
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3">
                    <CloudUpload size={32} className="text-[var(--color-bronze)]" />
                    <p className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
                      Drag & drop your ID or click to browse
                    </p>
                    <p className="text-xs" style={{ color: "var(--color-text-secondary)" }}>
                      Supported: Driver's License, State ID, Passport
                    </p>
                  </div>
                )}
              </div>
              {errors.idDocument && <p className="text-xs mt-1 text-red-500">{errors.idDocument}</p>}
            </div>

            {/* Face Capture Section */}
            <div className="pt-4">
              <div className="flex items-center gap-2 mb-4">
                <Camera size={20} className="text-[var(--color-bronze)]" />
                <h3 className="text-lg font-semibold" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
                  Face Verification
                </h3>
              </div>

              <div className="flex flex-col items-center gap-4">
                {faceCapture ? (
                  <div className="relative">
                    <img src={faceCapture} alt="Captured face" className="w-80 h-60 object-cover rounded-2xl border-2 border-[var(--color-bronze)]" />
                    <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/20">
                      <Check size={16} className="text-green-500" />
                      <span className="text-xs font-medium text-green-500">Verification photo captured</span>
                    </div>
                  </div>
                ) : (
                  <div className="relative">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className={`w-80 h-60 object-cover rounded-2xl border-2 ${cameraActive ? "border-[var(--color-bronze)]" : "border-[var(--color-border)]"}`}
                      style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8" }}
                    />
                    {!cameraActive && (
                      <div className="absolute inset-0 flex items-center justify-center rounded-2xl" style={{ backgroundColor: theme === "dark" ? "rgba(10,14,26,0.8)" : "rgba(245,240,232,0.8)" }}>
                        <button
                          type="button"
                          onClick={startCamera}
                          className="px-6 py-3 rounded-xl text-sm font-medium bronze-gradient text-white flex items-center gap-2"
                        >
                          <Camera size={18} /> Start Camera
                        </button>
                      </div>
                    )}
                  </div>
                )}

                <canvas ref={canvasRef} className="hidden" />

                {cameraActive && (
                  <div className="flex items-center gap-3">
                    <button type="button" onClick={captureFace} className="px-6 py-3 rounded-xl text-sm font-medium bronze-gradient text-white flex items-center gap-2">
                      <Camera size={18} /> Capture Photo
                    </button>
                    <button type="button" onClick={stopCamera} className="px-4 py-3 rounded-xl text-sm font-medium border" style={{ borderColor: "var(--color-border)", color: "var(--color-text-secondary)" }}>
                      Cancel
                    </button>
                  </div>
                )}

                {faceCapture && (
                  <button
                    type="button"
                    onClick={() => { setFaceCapture(null); startCamera(); }}
                    className="flex items-center gap-2 text-sm"
                    style={{ color: "var(--color-bronze)" }}
                  >
                    <RefreshCw size={16} /> Retake Photo
                  </button>
                )}
              </div>
              {errors.faceCapture && <p className="text-xs mt-1 text-red-500 text-center">{errors.faceCapture}</p>}
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-4 rounded-xl text-white font-semibold text-base bronze-gradient transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <RefreshCw size={18} className="animate-spin" /> Processing...
                </>
              ) : (
                "Submit & Generate My Fan Card"
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}