import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useTheme } from "@/providers/theme";
import { Download, CreditCard, Star, Shield, ShoppingBag, Music, Users, DollarSign } from "lucide-react";
import { toast } from "sonner";

export default function Card() {
  const { theme } = useTheme();
  const navigate = useNavigate();
  const [fanId, setFanId] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("fanId");
    if (stored) {
      setFanId(stored);
    }
  }, []);

  const { data: fan } = trpc.fan.getById.useQuery(
    { fanId: fanId || "" },
    { enabled: !!fanId }
  );

  const formatDate = (days: number) => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toLocaleDateString("en-US", { month: "short", year: "numeric" });
  };

  const handleDownload = () => {
    const cardElement = document.getElementById("fan-card");
    if (!cardElement) return;
    toast.success("Card downloaded! (Simulated)");
  };

  if (!fanId) {
    return (
      <div className="min-h-screen pt-24 px-4 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center" style={{ backgroundColor: theme === "dark" ? "rgba(184,134,11,0.1)" : "rgba(184,134,11,0.05)" }}>
            <CreditCard size={36} className="text-[var(--color-bronze)]" />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
            No Fan Card Found
          </h2>
          <p className="text-sm mb-6" style={{ color: "var(--color-text-secondary)" }}>
            You haven't registered yet. Complete the registration to receive your Bronze Fan ID card.
          </p>
          <Link
            to="/register"
            className="inline-block px-8 py-3 rounded-xl text-white font-semibold bronze-gradient"
          >
            Register Now
          </Link>
        </div>
      </div>
    );
  }

  if (!fan) {
    return (
      <div className="min-h-screen pt-24 px-4 flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-80 h-48 rounded-2xl" style={{ backgroundColor: "var(--color-surface)" }} />
          <p style={{ color: "var(--color-text-secondary)" }}>Loading your fan card...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
            Your Bronze Fan Card
          </h1>
          <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
            Exclusive membership for verified fans
          </p>
        </div>

        {/* Card */}
        <div className="relative mb-8">
          <div
            id="fan-card"
            className="relative w-full max-w-[500px] mx-auto overflow-hidden rounded-[20px]"
            style={{
              aspectRatio: "1.586",
              background: "linear-gradient(135deg, #8b6914 0%, #4a3508 50%, #8b6914 100%)",
              border: "3px solid transparent",
              backgroundClip: "padding-box",
              boxShadow: "0 0 30px rgba(184,134,11,0.4), 0 10px 40px rgba(0,0,0,0.3)",
            }}
          >
            {/* Shimmer overlay */}
            <div className="absolute inset-0 pointer-events-none animate-shimmer" style={{ background: "linear-gradient(90deg, transparent, rgba(255,215,0,0.15), transparent)" }} />

            {/* Card content */}
            <div className="relative z-10 p-6 h-full flex flex-col justify-between">
              {/* Top */}
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-xs font-bold tracking-[3px]" style={{ color: "#ffd700" }}>BRONZE MEMBER</p>
                  <p className="text-[10px] mt-1" style={{ color: "rgba(255,255,255,0.5)" }}>Official Jim Newman Fan Club</p>
                </div>
                <Star size={20} className="text-[#ffd700]" fill="#ffd700" />
              </div>

              {/* Middle */}
              <div className="flex items-center gap-5">
                <div className="w-24 h-28 rounded-xl overflow-hidden border-2" style={{ borderColor: "rgba(255,215,0,0.5)" }}>
                  {fan.faceCaptureUrl ? (
                    <img src={fan.faceCaptureUrl} alt="Member" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: "rgba(0,0,0,0.3)" }}>
                      <Shield size={32} style={{ color: "rgba(255,215,0,0.5)" }} />
                    </div>
                  )}
                </div>
                <div>
                  <p className="text-[10px] uppercase tracking-wider mb-1" style={{ color: "rgba(255,255,255,0.5)" }}>Fan ID</p>
                  <p className="text-xl font-bold tracking-wider mb-3" style={{ color: "#ffd700", fontFamily: "monospace" }}>
                    {fan.fanId}
                  </p>
                  <p className="text-[10px] uppercase tracking-wider mb-1" style={{ color: "rgba(255,255,255,0.5)" }}>Member Name</p>
                  <p className="text-base font-semibold text-white">{fan.fullName}</p>
                  <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.6)" }}>@{fan.instagramUsername}</p>
                </div>
              </div>

              {/* Bottom */}
              <div className="flex justify-between items-end">
                <div>
                  <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.5)" }}>VALID THRU</p>
                  <p className="text-sm font-medium" style={{ color: "#ffd700" }}>{formatDate(30)}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold" style={{ color: "#ffd700" }}>$1,500 BALANCE</p>
                  <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.5)" }}>Withdrawable</p>
                </div>
                <div className="w-12 h-12 rounded-full border-2 flex items-center justify-center" style={{ borderColor: "rgba(255,215,0,0.5)" }}>
                  <Star size={20} className="text-[#ffd700]" fill="#ffd700" />
                </div>
              </div>
            </div>

            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03]">
              <span className="text-8xl font-bold text-white rotate-[-15deg]">JM</span>
            </div>
          </div>
        </div>

        {/* Benefits */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          {[
            { icon: <ShoppingBag size={20} />, label: "30 Days Food" },
            { icon: <Music size={20} />, label: "Free Events" },
            { icon: <Users size={20} />, label: "Meet & Greet" },
            { icon: <DollarSign size={20} />, label: "$1,500 Balance" },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-xl" style={{ backgroundColor: theme === "dark" ? "rgba(184,134,11,0.1)" : "rgba(184,134,11,0.05)" }}>
              <div className="text-[var(--color-bronze)]">{item.icon}</div>
              <span className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>{item.label}</span>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={handleDownload}
            className="flex-1 py-3 rounded-xl text-sm font-medium border-2 flex items-center justify-center gap-2 transition-all duration-300 hover:border-[var(--color-bronze)] hover:text-[var(--color-bronze)]"
            style={{ borderColor: "var(--color-bronze)", color: "var(--color-bronze)" }}
          >
            <Download size={18} /> Download Card
          </button>
          <button
            onClick={() => navigate("/payment")}
            className="flex-1 py-3 rounded-xl text-sm font-medium text-white bronze-gradient flex items-center justify-center gap-2 transition-all duration-300 hover:scale-[1.02]"
          >
            <CreditCard size={18} /> Continue to Payment
          </button>
        </div>
      </div>
    </div>
  );
}
