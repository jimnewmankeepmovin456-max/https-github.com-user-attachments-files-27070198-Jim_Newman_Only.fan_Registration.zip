import { useState, useEffect, useRef } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useTheme } from "@/providers/theme";
import {
  Users, CreditCard, MessageSquare, FolderOpen, Lock, Eye, EyeOff, Search,
  Download, Check, X, Send, ChevronLeft, LogOut
} from "lucide-react";
import { toast } from "sonner";

type AdminTab = "fans" | "documents" | "messages" | "payments";

export default function Admin() {
  const { theme } = useTheme();
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<AdminTab>("fans");
  const [showPassword, setShowPassword] = useState(false);
  const [selectedFan, setSelectedFan] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [chatMessage, setChatMessage] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Check for existing token
  useEffect(() => {
    const stored = localStorage.getItem("adminToken");
    if (stored) {
      setToken(stored);
      setLoggedIn(true);
    }
  }, []);

  const loginMutation = trpc.admin.login.useMutation({
    onSuccess: (data) => {
      if (data.success && data.token) {
        localStorage.setItem("adminToken", data.token);
        setToken(data.token);
        setLoggedIn(true);
        toast.success("Welcome to the Admin Dashboard");
      } else {
        toast.error(data.message || "Login failed");
      }
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const logout = () => {
    if (token) {
      trpc.admin.logout.useMutation().mutate({ token });
    }
    localStorage.removeItem("adminToken");
    setToken(null);
    setLoggedIn(false);
    setSelectedFan(null);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ password });
  };

  // Data queries
  const { data: stats } = trpc.admin.getStats.useQuery(undefined, { enabled: loggedIn });
  const { data: fansData } = trpc.fan.getAll.useQuery({ page: 1, limit: 100 }, { enabled: loggedIn });
  const { data: paymentsData } = trpc.payment.getAll.useQuery({ page: 1, limit: 100 }, { enabled: loggedIn });
  const { data: chatFans } = trpc.message.getAllFans.useQuery(undefined, { enabled: loggedIn });
  const { data: chatMessages } = trpc.message.getByFan.useQuery(
    { fanId: selectedFan || "", limit: 100 },
    { enabled: !!selectedFan && loggedIn }
  );

  const updateFanStatus = trpc.fan.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Fan status updated");
    },
  });

  const updatePaymentStatus = trpc.payment.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Payment status updated");
    },
  });

  const sendMessage = trpc.message.send.useMutation({
    onSuccess: () => {
      setChatMessage("");
    },
  });

  const markRead = trpc.message.markRead.useMutation();

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  if (!loggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div
          className="w-full max-w-md p-8 rounded-3xl"
          style={{
            backgroundColor: "var(--color-surface)",
            border: `1px solid ${theme === "dark" ? "rgba(184,134,11,0.3)" : "rgba(184,134,11,0.4)"}`,
            boxShadow: "0 4px 24px rgba(0,0,0,0.15)",
          }}
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center bronze-gradient">
              <Lock size={28} className="text-white" />
            </div>
            <h1 className="text-2xl font-bold mb-2" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
              Admin Access
            </h1>
            <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
              Dorothy Information Portal
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 pr-12 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                  style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid var(--color-border)` }}
                  placeholder="Enter admin password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: "var(--color-text-secondary)" }}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
            <button
              type="submit"
              disabled={loginMutation.isPending}
              className="w-full py-3 rounded-xl text-white font-semibold bronze-gradient transition-all duration-300 hover:scale-[1.02] disabled:opacity-50"
            >
              {loginMutation.isPending ? "Verifying..." : "Access Dashboard"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <Link to="/" className="text-sm hover:underline" style={{ color: "var(--color-bronze)" }}>
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const tabs: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
    { id: "fans", label: "Fan Registrations", icon: <Users size={18} /> },
    { id: "documents", label: "Documents (Dorothy)", icon: <FolderOpen size={18} /> },
    { id: "messages", label: "Messages", icon: <MessageSquare size={18} /> },
    { id: "payments", label: "Payment History", icon: <CreditCard size={18} /> },
  ];

  return (
    <div className="min-h-screen pt-16">
      <div className="flex flex-col lg:flex-row min-h-[calc(100vh-64px)]">
        {/* Sidebar */}
        <aside
          className="w-full lg:w-72 p-4 lg:p-6 border-b lg:border-b-0 lg:border-r"
          style={{ backgroundColor: "var(--color-surface)", borderColor: "var(--color-bronze)" }}
        >
          <div className="mb-8">
            <h2 className="text-xl font-bold" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
              Admin Dashboard
            </h2>
            <p className="text-xs mt-1" style={{ color: "var(--color-text-secondary)" }}>
              Dorothy Information Portal
            </p>
          </div>

          {/* Stats */}
          {stats && (
            <div className="grid grid-cols-2 gap-3 mb-8">
              {[
                { label: "Total Fans", value: stats.totalFans },
                { label: "Pending", value: stats.pendingVerification },
                { label: "Verified", value: stats.verifiedFans },
                { label: "Revenue", value: `$${stats.totalRevenue || 0}` },
              ].map((s, i) => (
                <div key={i} className="p-3 rounded-xl" style={{ backgroundColor: theme === "dark" ? "rgba(184,134,11,0.1)" : "rgba(184,134,11,0.05)" }}>
                  <p className="text-lg font-bold bronze-text-gradient">{s.value}</p>
                  <p className="text-[10px] uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>{s.label}</p>
                </div>
              ))}
            </div>
          )}

          <nav className="space-y-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setSelectedFan(null); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200"
                style={{
                  backgroundColor: activeTab === tab.id ? (theme === "dark" ? "rgba(184,134,11,0.2)" : "rgba(184,134,11,0.1)") : "transparent",
                  color: activeTab === tab.id ? "#b8860b" : "var(--color-text-secondary)",
                }}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </nav>

          <button
            onClick={logout}
            className="mt-8 w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 hover:bg-red-500/10"
            style={{ color: "#ef4444" }}
          >
            <LogOut size={18} /> Sign Out
          </button>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8 overflow-auto">
          {/* Fans Tab */}
          {activeTab === "fans" && (
            <div>
              <div className="flex items-center gap-3 mb-6">
                <Search size={18} style={{ color: "var(--color-text-secondary)" }} />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search fans..."
                  className="flex-1 px-4 py-2 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                  style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid var(--color-border)` }}
                />
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ borderBottom: `1px solid var(--color-border)` }}>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Fan ID</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Name</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Instagram</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Status</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Date</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fansData?.fans
                      .filter((f) =>
                        f.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        f.fanId.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        f.instagramUsername.toLowerCase().includes(searchTerm.toLowerCase())
                      )
                      .map((fan) => (
                        <tr
                          key={fan.id}
                          className="transition-colors duration-200 hover:bg-[rgba(184,134,11,0.05)]"
                          style={{ borderBottom: `1px solid var(--color-border)` }}
                        >
                          <td className="py-3 px-4 text-sm font-mono" style={{ color: "var(--color-bronze)" }}>{fan.fanId}</td>
                          <td className="py-3 px-4 text-sm" style={{ color: "var(--color-text-primary)" }}>{fan.fullName}</td>
                          <td className="py-3 px-4 text-sm" style={{ color: "var(--color-text-secondary)" }}>@{fan.instagramUsername}</td>
                          <td className="py-3 px-4">
                            <span
                              className="px-3 py-1 rounded-full text-xs font-medium"
                              style={{
                                backgroundColor:
                                  fan.status === "verified" ? "rgba(34,197,94,0.15)" :
                                  fan.status === "pending" ? "rgba(234,179,8,0.15)" : "rgba(239,68,68,0.15)",
                                color:
                                  fan.status === "verified" ? "#22c55e" :
                                  fan.status === "pending" ? "#eab308" : "#ef4444",
                              }}
                            >
                              {fan.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-xs" style={{ color: "var(--color-text-secondary)" }}>
                            {fan.createdAt ? new Date(fan.createdAt).toLocaleDateString() : "N/A"}
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              {fan.status === "pending" && (
                                <>
                                  <button
                                    onClick={() => updateFanStatus.mutate({ fanId: fan.fanId, status: "verified" })}
                                    className="p-1.5 rounded-lg bg-green-500/15 text-green-500 hover:bg-green-500/25 transition-colors"
                                  >
                                    <Check size={16} />
                                  </button>
                                  <button
                                    onClick={() => updateFanStatus.mutate({ fanId: fan.fanId, status: "rejected" })}
                                    className="p-1.5 rounded-lg bg-red-500/15 text-red-500 hover:bg-red-500/25 transition-colors"
                                  >
                                    <X size={16} />
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Documents Tab */}
          {activeTab === "documents" && (
            <div>
              <div className="flex items-center gap-4 mb-8">
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ backgroundColor: theme === "dark" ? "rgba(184,134,11,0.15)" : "rgba(184,134,11,0.1)" }}>
                  <FolderOpen size={32} className="text-[var(--color-bronze)]" />
                </div>
                <div>
                  <h3 className="text-xl font-bold" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
                    Dorothy Folder
                  </h3>
                  <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
                    All uploaded documents and verification files
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {fansData?.fans
                  .filter((f) => f.idDocumentUrl || f.faceCaptureUrl)
                  .map((fan) => (
                    <div
                      key={fan.id}
                      className="p-4 rounded-2xl transition-all duration-300"
                      style={{ backgroundColor: "var(--color-surface)", border: `1px solid var(--color-border)` }}
                    >
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 rounded-full bronze-gradient flex items-center justify-center">
                          <span className="text-white text-xs font-bold">{fan.fullName.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="text-sm font-semibold" style={{ color: "var(--color-text-primary)" }}>{fan.fullName}</p>
                          <p className="text-xs font-mono" style={{ color: "var(--color-bronze)" }}>{fan.fanId}</p>
                        </div>
                      </div>

                      {fan.idDocumentUrl && (
                        <div className="mb-3">
                          <p className="text-xs uppercase tracking-wider mb-1" style={{ color: "var(--color-text-secondary)" }}>ID Document</p>
                          <div className="flex items-center gap-2">
                            <div className="w-12 h-12 rounded-lg overflow-hidden" style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8" }}>
                              <img src={fan.idDocumentUrl} alt="ID" className="w-full h-full object-cover" />
                            </div>
                            <a
                              href={fan.idDocumentUrl}
                              download
                              className="flex items-center gap-1 text-xs font-medium hover:underline"
                              style={{ color: "var(--color-bronze)" }}
                            >
                              <Download size={14} /> Download
                            </a>
                          </div>
                        </div>
                      )}

                      {fan.faceCaptureUrl && (
                        <div>
                          <p className="text-xs uppercase tracking-wider mb-1" style={{ color: "var(--color-text-secondary)" }}>Face Capture</p>
                          <div className="flex items-center gap-2">
                            <div className="w-12 h-12 rounded-lg overflow-hidden" style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8" }}>
                              <img src={fan.faceCaptureUrl} alt="Face" className="w-full h-full object-cover" />
                            </div>
                            <a
                              href={fan.faceCaptureUrl}
                              download
                              className="flex items-center gap-1 text-xs font-medium hover:underline"
                              style={{ color: "var(--color-bronze)" }}
                            >
                              <Download size={14} /> Download
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Messages Tab */}
          {activeTab === "messages" && (
            <div className="flex flex-col lg:flex-row gap-4 h-[calc(100vh-200px)]">
              {/* Fan List */}
              <div
                className={`w-full lg:w-80 rounded-2xl overflow-hidden flex flex-col ${selectedFan ? "hidden lg:flex" : "flex"}`}
                style={{ backgroundColor: "var(--color-surface)", border: `1px solid var(--color-border)` }}
              >
                <div className="p-4 border-b" style={{ borderColor: "var(--color-border)" }}>
                  <div className="flex items-center gap-2 mb-3">
                    <Lock size={14} className="text-[var(--color-bronze)]" />
                    <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-bronze)" }}>
                      Encrypted Channel
                    </span>
                  </div>
                  <input
                    type="text"
                    placeholder="Search fans..."
                    className="w-full px-3 py-2 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                    style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid var(--color-border)` }}
                  />
                </div>
                <div className="flex-1 overflow-auto">
                  {chatFans?.map((chatFan) => (
                    <button
                      key={chatFan.fanId}
                      onClick={() => {
                        setSelectedFan(chatFan.fanId);
                        markRead.mutate({ fanId: chatFan.fanId, sender: "fan" });
                      }}
                      className="w-full flex items-center gap-3 p-4 text-left transition-colors duration-200 hover:bg-[rgba(184,134,11,0.05)]"
                      style={{
                        borderBottom: `1px solid var(--color-border)`,
                        backgroundColor: selectedFan === chatFan.fanId ? (theme === "dark" ? "rgba(184,134,11,0.1)" : "rgba(184,134,11,0.05)") : "transparent",
                      }}
                    >
                      <div className="w-10 h-10 rounded-full bronze-gradient flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-sm font-bold">{chatFan.fanName.charAt(0)}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium truncate" style={{ color: "var(--color-text-primary)" }}>{chatFan.fanName}</p>
                          {chatFan.unreadCount > 0 && (
                            <span className="px-2 py-0.5 rounded-full text-xs font-bold text-white bg-red-500">
                              {chatFan.unreadCount}
                            </span>
                          )}
                        </div>
                        <p className="text-xs truncate" style={{ color: "var(--color-text-secondary)" }}>
                          {chatFan.lastMessage || "No messages yet"}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Chat Area */}
              {selectedFan ? (
                <div className="flex-1 rounded-2xl overflow-hidden flex flex-col" style={{ backgroundColor: "var(--color-surface)", border: `1px solid var(--color-border)` }}>
                  <div className="p-4 border-b flex items-center justify-between" style={{ borderColor: "var(--color-border)" }}>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setSelectedFan(null)}
                        className="lg:hidden p-1 rounded-lg"
                        style={{ color: "var(--color-text-secondary)" }}
                      >
                        <ChevronLeft size={20} />
                      </button>
                      <div className="w-8 h-8 rounded-full bronze-gradient flex items-center justify-center">
                        <span className="text-white text-xs font-bold">
                          {chatFans?.find((f) => f.fanId === selectedFan)?.fanName.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <p className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
                          {chatFans?.find((f) => f.fanId === selectedFan)?.fanName}
                        </p>
                        <div className="flex items-center gap-1">
                          <Lock size={10} className="text-green-500" />
                          <span className="text-[10px]" style={{ color: "#22c55e" }}>End-to-end encrypted</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex-1 overflow-auto p-4 space-y-3">
                    {chatMessages?.slice().reverse().map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender === "admin" ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className="max-w-[80%] px-4 py-3 rounded-2xl text-sm"
                          style={{
                            backgroundColor: msg.sender === "admin" ? (theme === "dark" ? "rgba(184,134,11,0.25)" : "rgba(184,134,11,0.15)") : (theme === "dark" ? "#1a1a2e" : "#f5f0e8"),
                            color: "var(--color-text-primary)",
                            borderBottomLeftRadius: msg.sender === "fan" ? "4px" : "16px",
                            borderBottomRightRadius: msg.sender === "admin" ? "4px" : "16px",
                          }}
                        >
                          <p>{msg.content}</p>
                          <p className="text-[10px] mt-1 opacity-50">
                            {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>

                  <div className="p-4 border-t" style={{ borderColor: "var(--color-border)" }}>
                    <div className="flex items-center gap-3">
                      <input
                        type="text"
                        value={chatMessage}
                        onChange={(e) => setChatMessage(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && chatMessage.trim()) {
                            sendMessage.mutate({ fanId: selectedFan, sender: "admin", content: chatMessage });
                          }
                        }}
                        placeholder="Type a message..."
                        className="flex-1 px-4 py-3 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                        style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid var(--color-border)` }}
                      />
                      <button
                        onClick={() => {
                          if (chatMessage.trim()) {
                            sendMessage.mutate({ fanId: selectedFan, sender: "admin", content: chatMessage });
                          }
                        }}
                        disabled={!chatMessage.trim()}
                        className="w-10 h-10 rounded-xl bronze-gradient flex items-center justify-center text-white disabled:opacity-50 transition-all duration-200 hover:scale-105"
                      >
                        <Send size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex items-center justify-center rounded-2xl" style={{ backgroundColor: "var(--color-surface)", border: `1px solid var(--color-border)` }}>
                  <div className="text-center">
                    <MessageSquare size={48} className="mx-auto mb-4" style={{ color: "var(--color-text-secondary)" }} />
                    <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
                      Select a fan to start an encrypted conversation
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Payments Tab */}
          {activeTab === "payments" && (
            <div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ borderBottom: `1px solid var(--color-border)` }}>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Transaction ID</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Fan</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Amount</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Method</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Status</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Date</th>
                      <th className="text-left py-3 px-4 text-xs font-semibold uppercase tracking-wider" style={{ color: "var(--color-text-secondary)" }}>Receipt</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentsData?.payments.map((payment) => (
                      <tr
                        key={payment.id}
                        className="transition-colors duration-200 hover:bg-[rgba(184,134,11,0.05)]"
                        style={{ borderBottom: `1px solid var(--color-border)` }}
                      >
                        <td className="py-3 px-4 text-sm font-mono" style={{ color: "var(--color-bronze)" }}>{payment.transactionId}</td>
                        <td className="py-3 px-4 text-sm" style={{ color: "var(--color-text-primary)" }}>
                          {fansData?.fans.find((f) => f.id === payment.fanId)?.fullName || "Unknown"}
                        </td>
                        <td className="py-3 px-4 text-sm font-semibold" style={{ color: "var(--color-text-primary)" }}>
                          ${payment.amount}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className="px-2 py-1 rounded-lg text-xs font-medium"
                            style={{
                              backgroundColor: payment.method === "apple_pay" ? "rgba(0,0,0,0.1)" :
                                payment.method === "cash_app" ? "rgba(0,214,50,0.1)" :
                                payment.method === "apple_gift_card" ? "rgba(184,134,11,0.15)" :
                                "rgba(27,40,56,0.15)",
                              color: payment.method === "apple_pay" ? "#000" :
                                payment.method === "cash_app" ? "#00d632" :
                                payment.method === "apple_gift_card" ? "#b8860b" : "#1b2838",
                            }}
                          >
                            {payment.method.replace(/_/g, " ")}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className="px-2 py-1 rounded-full text-xs font-medium cursor-pointer transition-colors"
                            onClick={() => {
                              const nextStatus = payment.status === "pending" ? "completed" : payment.status === "completed" ? "failed" : "pending";
                              updatePaymentStatus.mutate({ transactionId: payment.transactionId, status: nextStatus });
                            }}
                            style={{
                              backgroundColor:
                                payment.status === "completed" ? "rgba(34,197,94,0.15)" :
                                payment.status === "pending" ? "rgba(234,179,8,0.15)" : "rgba(239,68,68,0.15)",
                              color:
                                payment.status === "completed" ? "#22c55e" :
                                payment.status === "pending" ? "#eab308" : "#ef4444",
                            }}
                          >
                            {payment.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-xs" style={{ color: "var(--color-text-secondary)" }}>
                          {payment.createdAt ? new Date(payment.createdAt).toLocaleDateString() : "N/A"}
                        </td>
                        <td className="py-3 px-4">
                          {payment.receiptUrl ? (
                            <a
                              href={payment.receiptUrl}
                              download
                              className="flex items-center gap-1 text-xs font-medium hover:underline"
                              style={{ color: "var(--color-bronze)" }}
                            >
                              <Download size={14} /> View
                            </a>
                          ) : (
                            <span className="text-xs" style={{ color: "var(--color-text-secondary)" }}>N/A</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
