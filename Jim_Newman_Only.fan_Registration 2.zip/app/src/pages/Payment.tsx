import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useTheme } from "@/providers/theme";
import { CreditCard, Gamepad, Apple, DollarSign, Lock, CloudUpload, Check } from "lucide-react";
import { toast } from "sonner";

export default function Payment() {
  const { theme } = useTheme();
  const navigate = useNavigate();
  const [method, setMethod] = useState<"apple_gift_card" | "cash_app" | "steam_card" | "apple_pay" | null>(null);
  const [receipt, setReceipt] = useState<string | null>(null);
  const [cashAppTag, setCashAppTag] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const paymentMutation = trpc.payment.create.useMutation({
    onSuccess: (data) => {
      toast.success(data.message);
      navigate("/card");
    },
    onError: (error) => {
      toast.error(error.message);
      setSubmitting(false);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => setReceipt(event.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = () => {
    const fanId = localStorage.getItem("fanId");
    if (!fanId) {
      toast.error("Please register first");
      return;
    }
    if (!method) {
      toast.error("Please select a payment method");
      return;
    }
    if (method === "cash_app" && !cashAppTag) {
      toast.error("Please enter your $Cashtag");
      return;
    }
    if ((method === "apple_gift_card" || method === "steam_card") && !receipt) {
      toast.error("Please upload your gift card image");
      return;
    }

    setSubmitting(true);
    paymentMutation.mutate({
      fanId,
      amount: 1000,
      method,
      receipt: receipt || undefined,
      cashAppTag: cashAppTag || undefined,
    });
  };

  const methods = [
    {
      id: "apple_gift_card" as const,
      icon: <CreditCard size={24} />,
      title: "Apple Gift Card",
      desc: "Upload Apple Gift Card image",
      color: "#b8860b",
    },
    {
      id: "cash_app" as const,
      icon: <DollarSign size={24} />,
      title: "Cash App",
      desc: "Cash App Transfer",
      color: "#00d632",
    },
    {
      id: "steam_card" as const,
      icon: <Gamepad size={24} />,
      title: "Steam Card",
      desc: "Upload Steam Gift Card image",
      color: "#1b2838",
    },
    {
      id: "apple_pay" as const,
      icon: <Apple size={24} />,
      title: "Apple Pay",
      desc: "Secure checkout",
      color: "#000000",
    },
  ];

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-xl mx-auto">
        <div
          className="rounded-3xl p-8 md:p-10"
          style={{
            backgroundColor: "var(--color-surface)",
            border: `1px solid ${theme === "dark" ? "rgba(184,134,11,0.3)" : "rgba(184,134,11,0.4)"}`,
            boxShadow: "0 4px 24px rgba(0,0,0,0.15)",
          }}
        >
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold mb-2" style={{ color: "var(--color-text-primary)", fontFamily: "Playfair Display, serif" }}>
              Complete Your Registration
            </h1>
            <div className="flex items-baseline justify-center gap-1">
              <span className="text-4xl font-bold bronze-text-gradient" style={{ fontFamily: "Playfair Display, serif" }}>
                $1,000.00
              </span>
            </div>
            <p className="text-xs mt-1" style={{ color: "var(--color-text-secondary)" }}>
              Registration Fee — One-time payment
            </p>
          </div>

          {/* Payment Methods */}
          <div className="space-y-3 mb-8">
            {methods.map((m) => (
              <div
                key={m.id}
                onClick={() => setMethod(m.id)}
                className="flex items-center gap-4 p-4 rounded-xl cursor-pointer transition-all duration-300 border"
                style={{
                  borderColor: method === m.id ? "#b8860b" : "var(--color-border)",
                  backgroundColor: method === m.id ? (theme === "dark" ? "rgba(184,134,11,0.1)" : "rgba(184,134,11,0.05)") : "transparent",
                }}
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${m.color}20`, color: m.color }}
                >
                  {m.icon}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold" style={{ color: "var(--color-text-primary)" }}>{m.title}</p>
                  <p className="text-xs" style={{ color: "var(--color-text-secondary)" }}>{m.desc}</p>
                </div>
                <div
                  className="w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all duration-300"
                  style={{ borderColor: method === m.id ? "#b8860b" : "var(--color-border)" }}
                >
                  {method === m.id && <div className="w-3 h-3 rounded-full bronze-gradient" />}
                </div>
              </div>
            ))}
          </div>

          {/* Cash App Tag Input */}
          {method === "cash_app" && (
            <div className="mb-6">
              <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                Your $Cashtag
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-sm font-bold" style={{ color: "var(--color-bronze)" }}>$</span>
                <input
                  type="text"
                  value={cashAppTag}
                  onChange={(e) => setCashAppTag(e.target.value)}
                  className="w-full pl-8 pr-4 py-3 rounded-xl text-sm transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                  style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid var(--color-border)` }}
                  placeholder="YourCashtag"
                />
              </div>
            </div>
          )}

          {/* Gift Card Upload */}
          {(method === "apple_gift_card" || method === "steam_card") && (
            <div className="mb-6">
              <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: "var(--color-text-secondary)" }}>
                Upload Gift Card
              </label>
              <div
                className="border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-300 hover:border-[var(--color-bronze)]"
                style={{ borderColor: "#cd7f32" }}
                onClick={() => document.getElementById("receipt-upload")?.click()}
              >
                <input id="receipt-upload" type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                {receipt ? (
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                      <Check size={20} className="text-green-500" />
                    </div>
                    <p className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>Receipt uploaded</p>
                    <button
                      onClick={(e) => { e.stopPropagation(); setReceipt(null); }}
                      className="text-xs underline"
                      style={{ color: "var(--color-text-secondary)" }}
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <CloudUpload size={28} className="text-[var(--color-bronze)]" />
                    <p className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>
                      Upload your gift card image or receipt
                    </p>
                    <p className="text-xs" style={{ color: "var(--color-text-secondary)" }}>
                      JPG, PNG up to 10MB
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Apple Pay Note */}
          {method === "apple_pay" && (
            <div className="mb-6 p-4 rounded-xl" style={{ backgroundColor: theme === "dark" ? "rgba(59,130,246,0.1)" : "rgba(59,130,246,0.05)" }}>
              <p className="text-sm" style={{ color: "var(--color-text-secondary)" }}>
                You will be redirected to Apple Pay to complete the secure checkout.
              </p>
            </div>
          )}

          {/* Security Note */}
          <div className="flex items-center gap-2 mb-6 justify-center">
            <Lock size={14} className="text-[var(--color-text-secondary)]" />
            <p className="text-xs" style={{ color: "var(--color-text-secondary)" }}>
              All transactions are encrypted and secure
            </p>
          </div>

          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="w-full py-4 rounded-xl text-white font-semibold text-base bronze-gradient transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {submitting ? "Processing..." : "Complete Payment & Activate Benefits"}
          </button>
        </div>
      </div>
    </div>
  );
}
