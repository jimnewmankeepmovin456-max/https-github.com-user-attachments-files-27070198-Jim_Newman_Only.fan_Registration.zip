import { Link } from "react-router";
import { ShoppingBag, Music, Users, DollarSign, ChevronRight, Shield } from "lucide-react";
import { useTheme } from "@/providers/theme";

export default function Home() {
  const { theme } = useTheme();

  const benefits = [
    {
      icon: <ShoppingBag size={32} className="text-[var(--color-bronze)]" />,
      title: "30 Days Food Shopping",
      desc: "Complimentary grocery coverage with your fan ID",
    },
    {
      icon: <Music size={32} className="text-[var(--color-bronze)]" />,
      title: "Free Concert Access",
      desc: "VIP entry to all Jim Newman performances and events",
    },
    {
      icon: <Users size={32} className="text-[var(--color-bronze)]" />,
      title: "Meet & Greet Sessions",
      desc: "Exclusive backstage meetups and photo opportunities",
    },
    {
      icon: <DollarSign size={32} className="text-[var(--color-bronze)]" />,
      title: "$1,500 Withdrawable Balance",
      desc: "Cash benefit loaded on your verified fan card",
    },
  ];

  const steps = [
    { num: "1", title: "Register", desc: "Fill your details and upload ID" },
    { num: "2", title: "Verify", desc: "Complete face capture for security" },
    { num: "3", title: "Receive", desc: "Get your bronze fan card and benefits" },
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero Section */}
      <section className="relative py-20 px-4 overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ background: 'radial-gradient(ellipse at center top, rgba(184,134,11,0.3), transparent 70%)' }} />
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <div className="w-48 h-48 md:w-64 md:h-64 rounded-3xl overflow-hidden bronze-border bronze-glow">
                <img src="/jim-newman-hero.jpg" alt="Jim Newman" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-3 -right-3 w-20 h-20 rounded-full bronze-gradient flex items-center justify-center">
                <Shield size={28} className="text-white" />
              </div>
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-4 bronze-text-gradient" style={{ fontFamily: 'Playfair Display, serif' }}>
            JIM NEWMAN
          </h1>
          <p className="text-lg md:text-xl mb-2" style={{ color: 'var(--color-text-secondary)' }}>
            Official Fan Club Registration
          </p>
          <p className="text-xl md:text-2xl italic mb-8" style={{ color: '#ffd700', fontFamily: 'Playfair Display, serif' }}>
            Keep Movin' Together
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link
              to="/register"
              className="px-10 py-4 rounded-xl text-white font-semibold text-base bronze-gradient bronze-glow transition-all duration-300 hover:scale-105 flex items-center gap-2"
            >
              Become a Verified Fan <ChevronRight size={18} />
            </Link>
            <Link
              to="/card"
              className="px-8 py-4 rounded-xl text-sm font-medium transition-all duration-300 border hover:border-[var(--color-bronze)]"
              style={{ color: 'var(--color-text-secondary)', borderColor: 'var(--color-border)' }}
            >
              Already a member? Access your card
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12" style={{ color: 'var(--color-text-primary)', fontFamily: 'Playfair Display, serif' }}>
            Bronze Member Benefits
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((b, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl transition-all duration-300 card-hover"
                style={{ backgroundColor: 'var(--color-surface)', border: `1px solid ${theme === 'dark' ? 'rgba(184,134,11,0.2)' : 'rgba(184,134,11,0.3)'}` }}
              >
                <div className="mb-4">{b.icon}</div>
                <h3 className="text-lg font-semibold mb-2" style={{ color: 'var(--color-text-primary)' }}>{b.title}</h3>
                <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12" style={{ color: 'var(--color-text-primary)', fontFamily: 'Playfair Display, serif' }}>
            How It Works
          </h2>
          <div className="flex flex-col md:flex-row items-center justify-between gap-8 relative">
            {/* Connector line - desktop only */}
            <div className="hidden md:block absolute top-8 left-[15%] right-[15%] h-0.5 bronze-gradient" />
            
            {steps.map((step, i) => (
              <div key={i} className="flex flex-col items-center text-center relative z-10">
                <div className="w-16 h-16 rounded-full bronze-gradient flex items-center justify-center mb-4 shadow-lg">
                  <span className="text-white font-bold text-xl">{step.num}</span>
                </div>
                <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--color-text-primary)' }}>{step.title}</h3>
                <p className="text-sm max-w-[200px]" style={{ color: 'var(--color-text-secondary)' }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Imposter Awareness */}
      <section className="py-16 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="p-8 rounded-2xl border-2 border-[#b8860b] bg-[var(--color-surface)]">
            <div className="flex items-center gap-4 mb-4">
              <Shield size={32} className="text-[var(--color-gold)]" />
              <h3 className="text-2xl font-bold" style={{ color: 'var(--color-text-primary)', fontFamily: 'Playfair Display, serif' }}>
                Imposter Awareness
              </h3>
            </div>
            <p className="text-sm mb-4" style={{ color: 'var(--color-text-secondary)' }}>
              Please be aware that there are fake accounts and pages pretending to be Jim Newman.
            </p>
            <p className="text-sm font-semibold mb-4" style={{ color: '#ef4444' }}>
              He will NEVER message you privately asking for money, gifts, or personal information.
            </p>
            <div className="p-4 rounded-xl mb-4" style={{ backgroundColor: theme === 'dark' ? 'rgba(59,130,246,0.1)' : 'rgba(59,130,246,0.05)' }}>
              <p className="text-sm font-medium" style={{ color: '#3b82f6' }}>
                ALL official posts, updates, and activities are shared ONLY on
              </p>
              <p className="text-lg font-bold mt-1" style={{ color: '#3b82f6' }}>
                @jimnewmankeepmovin
              </p>
            </div>
            <p className="text-sm text-center" style={{ color: 'var(--color-text-secondary)' }}>
              Please make sure you follow and engage only there to stay connected with everything Jim does.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t" style={{ borderColor: 'var(--color-bronze)' }}>
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
            &copy; 2025 Jim Newman Fan Club. All rights reserved.
          </p>
          <a href="https://instagram.com/jimnewmankeepmovin" target="_blank" rel="noopener noreferrer" className="text-sm font-medium hover:underline" style={{ color: '#3b82f6' }}>
            @jimnewmankeepmovin
          </a>
        </div>
      </footer>
    </div>
  );
}
