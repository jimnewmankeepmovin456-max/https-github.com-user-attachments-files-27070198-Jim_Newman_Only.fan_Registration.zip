import { Link, useLocation } from "react-router";
import { useTheme } from "@/providers/theme";
import { Sun, Moon, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navbar() {
  const { theme, toggleTheme } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const links = [
    { path: "/", label: "Home" },
    { path: "/register", label: "Register" },
    { path: "/card", label: "Card" },
    { path: "/payment", label: "Payment" },
    { path: "/admin", label: "Admin" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 backdrop-blur-md bg-opacity-80 border-b transition-colors duration-300" style={{ backgroundColor: `${theme === 'dark' ? '#0a0e1a' : '#ffffff'}80`, borderColor: theme === 'dark' ? '#2a2a3e' : '#d4c5b0' }}>
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bronze-gradient flex items-center justify-center">
            <span className="text-white font-bold text-sm">JM</span>
          </div>
          <span className="font-semibold text-lg hidden sm:block" style={{ color: 'var(--color-text-primary)', fontFamily: 'Playfair Display, serif' }}>
            Fan Portal
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-6">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className="text-sm font-medium transition-colors duration-200 hover:text-[var(--color-bronze)]"
              style={{ color: location.pathname === link.path ? '#b8860b' : 'var(--color-text-secondary)' }}
            >
              {link.label}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleTheme}
            className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-[var(--color-border)]"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? <Sun size={18} className="text-[var(--color-gold)]" /> : <Moon size={18} className="text-[var(--color-bronze)]" />}
          </button>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden w-9 h-9 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-[var(--color-border)]"
          >
            {mobileOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 p-4 backdrop-blur-lg border-b transition-colors duration-300" style={{ backgroundColor: 'var(--color-bg)', borderColor: 'var(--color-border)' }}>
          <div className="flex flex-col gap-2">
            {links.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileOpen(false)}
                className="px-4 py-3 rounded-lg text-sm font-medium transition-colors duration-200"
                style={{ color: location.pathname === link.path ? '#b8860b' : 'var(--color-text-secondary)', backgroundColor: location.pathname === link.path ? `${theme === 'dark' ? 'rgba(184,134,11,0.1)' : 'rgba(184,134,11,0.05)'}` : 'transparent' }}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}
