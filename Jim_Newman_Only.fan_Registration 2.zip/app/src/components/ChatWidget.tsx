import { useState, useRef, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { useTheme } from "@/providers/theme";
import { MessageSquare, X, Send, Lock } from "lucide-react";
import { toast } from "sonner";

export default function ChatWidget() {
  const { theme } = useTheme();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [fanId, setFanId] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const stored = localStorage.getItem("fanId");
    if (stored) setFanId(stored);
  }, []);

  const { data: messages } = trpc.message.getByFan.useQuery(
    { fanId: fanId || "", limit: 100 },
    { enabled: !!fanId && open, refetchInterval: 3000 }
  );

  const sendMessage = trpc.message.send.useMutation({
    onSuccess: () => setMessage(""),
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (open) {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, open]);

  const handleSend = () => {
    if (!fanId) {
      toast.error("Please register first to use chat");
      return;
    }
    if (!message.trim()) return;
    sendMessage.mutate({ fanId, sender: "fan", content: message });
  };

  if (!fanId) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {open ? (
        <div
          className="w-80 h-96 rounded-2xl overflow-hidden flex flex-col shadow-2xl"
          style={{
            backgroundColor: "var(--color-surface)",
            border: `1px solid ${theme === "dark" ? "rgba(184,134,11,0.3)" : "rgba(184,134,11,0.4)"}`,
          }}
        >
          {/* Header */}
          <div className="p-4 border-b flex items-center justify-between" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bronze-gradient flex items-center justify-center">
                <span className="text-white text-xs font-bold">JM</span>
              </div>
              <div>
                <p className="text-sm font-medium" style={{ color: "var(--color-text-primary)" }}>Live Support</p>
                <div className="flex items-center gap-1">
                  <Lock size={10} className="text-green-500" />
                  <span className="text-[10px]" style={{ color: "#22c55e" }}>Encrypted</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:bg-[var(--color-border)]"
              style={{ color: "var(--color-text-secondary)" }}
            >
              <X size={16} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-auto p-3 space-y-3">
            {messages && messages.length > 0 ? (
              messages.slice().reverse().map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === "fan" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className="max-w-[85%] px-3 py-2 rounded-xl text-xs"
                    style={{
                      backgroundColor: msg.sender === "fan" ? (theme === "dark" ? "rgba(184,134,11,0.25)" : "rgba(184,134,11,0.15)") : (theme === "dark" ? "#1a1a2e" : "#f5f0e8"),
                      color: "var(--color-text-primary)",
                      borderBottomLeftRadius: msg.sender === "admin" ? "4px" : "12px",
                      borderBottomRightRadius: msg.sender === "fan" ? "4px" : "12px",
                    }}
                  >
                    <p>{msg.content}</p>
                    <p className="text-[9px] mt-1 opacity-50">
                      {msg.createdAt ? new Date(msg.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center px-4">
                <MessageSquare size={32} className="mb-2" style={{ color: "var(--color-text-secondary)" }} />
                <p className="text-xs" style={{ color: "var(--color-text-secondary)" }}>
                  Start a conversation with admin support
                </p>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t" style={{ borderColor: "var(--color-border)" }}>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Type a message..."
                className="flex-1 px-3 py-2 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[var(--color-bronze)]"
                style={{ backgroundColor: theme === "dark" ? "#1a1a2e" : "#f5f0e8", color: "var(--color-text-primary)", border: `1px solid var(--color-border)` }}
              />
              <button
                onClick={handleSend}
                disabled={!message.trim()}
                className="w-8 h-8 rounded-lg bronze-gradient flex items-center justify-center text-white disabled:opacity-50 transition-all hover:scale-105"
              >
                <Send size={14} />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setOpen(true)}
          className="w-14 h-14 rounded-full bronze-gradient flex items-center justify-center text-white shadow-lg transition-all duration-300 hover:scale-110 hover:shadow-xl"
        >
          <MessageSquare size={24} />
        </button>
      )}
    </div>
  );
}
