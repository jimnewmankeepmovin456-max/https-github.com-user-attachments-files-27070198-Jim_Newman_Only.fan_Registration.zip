import { relations } from "drizzle-orm";
import { fans, payments, messages } from "./schema";

export const fansRelations = relations(fans, ({ many }) => ({
  payments: many(payments),
  messages: many(messages),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  fan: one(fans, {
    fields: [payments.fanId],
    references: [fans.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  fan: one(fans, {
    fields: [messages.fanId],
    references: [fans.id],
  }),
}));
