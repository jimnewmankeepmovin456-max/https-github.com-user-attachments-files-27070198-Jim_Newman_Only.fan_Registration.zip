import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  boolean,
  date,
  decimal,
  bigint,
} from "drizzle-orm/mysql-core";

export const fans = mysqlTable("fans", {
  id: serial("id").primaryKey(),
  fanId: varchar("fan_id", { length: 20 }).notNull().unique(),
  fullName: varchar("full_name", { length: 100 }).notNull(),
  instagramUsername: varchar("instagram_username", { length: 50 }).notNull(),
  email: varchar("email", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull(),
  dateOfBirth: date("date_of_birth").notNull(),
  address: text("address").notNull(),
  idDocumentUrl: varchar("id_document_url", { length: 500 }),
  faceCaptureUrl: varchar("face_capture_url", { length: 500 }),
  status: mysqlEnum("status", ["pending", "verified", "rejected"]).default("pending"),
  cardGenerated: boolean("card_generated").default(false),
  cardActivated: boolean("card_activated").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
});

export const payments = mysqlTable("payments", {
  id: serial("id").primaryKey(),
  fanId: bigint("fan_id", { mode: "number", unsigned: true }).notNull().references(() => fans.id),
  transactionId: varchar("transaction_id", { length: 30 }).notNull().unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  method: mysqlEnum("method", ["apple_gift_card", "cash_app", "steam_card", "apple_pay"]).notNull(),
  receiptUrl: varchar("receipt_url", { length: 500 }),
  cashAppTag: varchar("cash_app_tag", { length: 50 }),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = mysqlTable("messages", {
  id: serial("id").primaryKey(),
  fanId: bigint("fan_id", { mode: "number", unsigned: true }).notNull().references(() => fans.id),
  sender: mysqlEnum("sender", ["fan", "admin"]).notNull(),
  content: text("content").notNull(),
  encrypted: boolean("encrypted").default(true),
  read: boolean("read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const adminSessions = mysqlTable("admin_sessions", {
  id: serial("id").primaryKey(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});
